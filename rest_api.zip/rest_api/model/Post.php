<?php
class Post{
	private $conn;
	private $table='tbl_file';
	
	public $id;
	public $p_name;
	public $p_category;
	public $p_price;
	public $image;
	
	public function __construct($db){
	 $this->conn = $db;
    }
	
	public function read(){
		$query = 'SELECT * FROM '.$this->table.'';
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
	
	public function read_single(){
		$query = 'SELECT * FROM '.$this->table.' WHERE id=?';
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $this->id);
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$this->p_name = $row['p_name'];
		$this->p_category = $row['p_category'];
		$this->p_price = $row['p_price'];
		$this->image = $row['image'];
	}
	
	public function create(){
		$query = 'INSERT INTO '.$this->table.' SET p_name= :p_name,p_category= :p_category,p_price= :p_price,image= :image';
		$stmt = $this->conn->prepare($query);
		
		$this->p_name = htmlspecialchars(strip_tags($this->p_name)); 
		$this->p_category = htmlspecialchars(strip_tags($this->p_category));  
		$this->p_price = htmlspecialchars(strip_tags($this->p_price));  
		$this->image = htmlspecialchars(strip_tags($this->image));  
		
		$stmt->bindParam(':p_name', $this->p_name);
		$stmt->bindParam(':p_category', $this->p_category);
		$stmt->bindParam(':p_price', $this->p_price);
		$stmt->bindParam(':image', $this->image);
		
		if($stmt->execute()){
			return true;
		}
		printf("Error: %s.\n", $stmt->error);
		return false;
	}
	
	public function update(){
		$query = 'UPDATE '.$this->table.' SET p_name= :p_name,p_category= :p_category,p_price= :p_price,image= :image WHERE id=:id';
		$stmt = $this->conn->prepare($query);
		
		$this->p_name = htmlspecialchars(strip_tags($this->p_name)); 
		$this->p_category = htmlspecialchars(strip_tags($this->p_category));  
		$this->p_price = htmlspecialchars(strip_tags($this->p_price));  
		$this->image = htmlspecialchars(strip_tags($this->image));  
		$this->id = htmlspecialchars(strip_tags($this->id));  
		
		$stmt->bindParam(':p_name', $this->p_name);
		$stmt->bindParam(':p_category', $this->p_category);
		$stmt->bindParam(':p_price', $this->p_price);
		$stmt->bindParam(':image', $this->image);
		$stmt->bindParam(':id', $this->id);
		
		if($stmt->execute()){
			return true;
		}
		printf("Error: %s.\n", $stmt->error);
		return false;
	}
	
	public function delete(){
		$query = 'DELETE FROM '.$this->table.' WHERE id=:id';
		$stmt = $this->conn->prepare($query);
		$this->id = htmlspecialchars(strip_tags($this->id));  
		$stmt->bindParam(':id', $this->id);
		if($stmt->execute()){
			return true;
		}
		printf("Error: %s.\n", $stmt->error);
		return false;
	}
		
}	
?>
