<?php
header('Content-Type: application/json');

include_once 'C:/xampp/htdocs/rest_api/config/database.php';
include_once 'C:/xampp/htdocs/rest_api/model/post.php';

$database = new Database();
$db = $database->connect();

$post = new Post($db);

$post->id = isset($_GET['id'])?$_GET['id']:die();
$post->read_single();

$post_arr = array('id'=>$post->id,
		'p_name'=>$post->p_name,
		'p_categoty'=>$post->p_category,
		'p_price'=>$post->p_price,
		'image'=>$post->image);
		
		print_r(json_encode($post_arr));
?>
